from setuptools import setup

setup(
    name="s1290181_learn",
    version="2023.07.28",
    install_requires=['pandas', 'plotly','pami', 're', 'pami'],
)